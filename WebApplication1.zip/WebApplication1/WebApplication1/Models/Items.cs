﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace WebApplication1.Models
{
    public class Items
    {
        public int ItemsID { get; set; }
        public string ItemsTitle { get; set; }
        public string ItemsDescribe { get; set; }
        public string ItemsDetail { get; set; }
        public string ItemsImage { get; set; }
    }
}